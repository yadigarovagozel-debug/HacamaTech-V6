
import { GoogleGenAI, Type } from "@google/genai";
import { SYSTEM_PROMPT } from "../constants";
import { MappingResult } from "../types";

const API_KEY = process.env.API_KEY || "";

export const analyzeAnatomy = async (base64Image: string): Promise<MappingResult> => {
  if (!API_KEY) throw new Error("API Key is missing.");

  const ai = new GoogleGenAI({ apiKey: API_KEY });
  // Using Pro for superior spatial reasoning as requested for medical-grade precision
  const model = "gemini-3-pro-preview";

  const response = await ai.models.generateContent({
    model,
    contents: [
      {
        parts: [
          { text: SYSTEM_PROMPT },
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image.split(",")[1],
            },
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          points: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                x: { type: Type.NUMBER },
                y: { type: Type.NUMBER },
                name: { type: Type.STRING },
                description: { type: Type.STRING },
              },
              required: ["id", "x", "y", "name"],
            },
          },
          landmarks: {
            type: Type.OBJECT,
            properties: {
              spineDetected: { type: Type.BOOLEAN },
              scapulaDetected: { type: Type.BOOLEAN },
              c7Detected: { type: Type.BOOLEAN },
            },
            required: ["spineDetected", "scapulaDetected", "c7Detected"],
          },
          confidenceScore: { type: Type.NUMBER },
        },
        required: ["points", "landmarks", "confidenceScore"],
      },
    },
  });

  const result = JSON.parse(response.text);
  
  return {
    points: result.points.map((p: any) => ({ ...p, verified: true })),
    anatomicalConfidence: result.confidenceScore,
    landmarks: result.landmarks,
  };
};
