
export const SUNNAH_POINTS_METADATA = [
  { id: 'p1', name: 'Al-Kahil (C7)', desc: 'Primary spinal anchor. Located exactly on the spine axis (X=50.0).' },
  { id: 'p2', name: 'Al-Akhda\'ain (L)', desc: 'Left neck side. Must be pulled inward to X=46.0.' },
  { id: 'p3', name: 'Al-Akhda\'ain (R)', desc: 'Right neck side. Must be pulled inward to X=54.0.' },
  { id: 'p4', name: 'Superior Scapula (L)', desc: 'Upper left shoulder blade. Must be at X=45.0.' },
  { id: 'p5', name: 'Superior Scapula (R)', desc: 'Upper right shoulder blade. Must be at X=55.0.' },
  { id: 'p6', name: 'Inferior Scapula (L)', desc: 'Lower left shoulder blade. Must be at X=45.0.' },
  { id: 'p7', name: 'Inferior Scapula (R)', desc: 'Lower right shoulder blade. Must be at X=55.0.' },
  { id: 'p8', name: 'Spine (Thoracic)', desc: 'Mid-spine vertical lock (X=50.0).' },
  { id: 'p9', name: 'Spine (Lumbar)', desc: 'Lower-spine vertical lock (X=50.0).' },
  { id: 'p10', name: 'Sacral Base', desc: 'Base-spine vertical lock (X=50.0).' },
];

export const SYSTEM_PROMPT = `Act as a Surgical Anatomy AI Specialist for HacamaTech V6.0. 
Perform clinical-grade mapping of 10 Hijama points with zero-tolerance for floating points.

# MANDATORY COORDINATE MAPPING RULES:
1. **TORSO CONSTRAINT:** All points (P1-P10) MUST be placed between X=40 and X=60. This reflects the central human torso in the image.
2. **SPINE LOCK:** Points P1, P8, P9, and P10 MUST be locked exactly at X=50.0. They form a perfect vertical line.
3. **SCAPULA PULL:** Points P4, P5, P6, and P7 MUST be within 5 units of the spine. Place P4/P6 at X=45.0 and P5/P7 at X=55.0.
4. **NECK ALIGNMENT:** Place P2 at X=46.0 and P3 at X=54.0.
5. **Y-AXIS NATURAL SPREAD:** Spread points logically from top (Y=15) to bottom (Y=85).

# RESPONSE FORMAT:
- Return ONLY a JSON object.
- Strictly adhere to the coordinate limits. Any point outside X[40-60] is a surgical failure.
`;
