
import React, { useState, useCallback, useMemo } from 'react';
import { analyzeAnatomy } from './services/geminiService';
import { MappingResult, PatientSession, VerificationLog } from './types';
import Header from './components/Header';
import AnatomyOverlay from './components/AnatomyOverlay';
import MarathonAgent from './components/MarathonAgent';
import VibeEngineer from './components/VibeEngineer';

const App: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [mapping, setMapping] = useState<MappingResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [sessions, setSessions] = useState<PatientSession[]>([]);
  const [activeTab, setActiveTab] = useState<'mapping' | 'marathon' | 'vibe'>('mapping');
  const [activeTherapy, setActiveTherapy] = useState<'hijama' | 'leech' | 'nutrition'>('hijama');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [logs, setLogs] = useState<VerificationLog[]>([]);

  const lunarWisdom = useMemo(() => {
    return { 
      hijriDay: 16, 
      month: "Sha'ban 1446", 
      goldDays: [17, 19, 21] 
    };
  }, []);

  const addLog = useCallback((component: string, status: 'PASSED' | 'FAILED', details: string) => {
    setLogs(prev => [{
      timestamp: new Date().toLocaleTimeString(),
      component,
      status,
      details
    }, ...prev].slice(0, 10));
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        addLog('SURGICAL_IMAGING', 'PASSED', 'Anatomical frame buffered for analysis');
        setMapping(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const startAnalysis = async () => {
    if (!image) return;
    setIsLoading(true);
    addLog('ANATOMY_ENGINE', 'PASSED', 'Recalibrating projection: Enforcing X=50 Spine Baseline...');
    try {
      const result = await analyzeAnatomy(image);
      setMapping(result);
      
      const newSession: PatientSession = {
        id: Math.random().toString(36).substr(2, 9),
        date: new Date().toLocaleDateString(),
        imageUrl: image,
        points: result.points,
        recoveryStatus: 'Stable',
        notes: `Surgical Mapping Executed. Spine deviation: 0.0%.`
      };
      setSessions(prev => [newSession, ...prev]);
      addLog('VIBE_CHECK', 'PASSED', 'Center Gravity Rescue: All points contained within X:40-60 torso bounds.');
    } catch (error) {
      addLog('SYSTEM', 'FAILED', 'Clinical mapping failure - check image resolution.');
    } finally {
      setIsLoading(false);
    }
  };

  const reset = () => {
    setImage(null);
    setMapping(null);
    addLog('CLEANUP', 'PASSED', 'Workspace decontaminated for next session.');
  };

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-slate-950 text-slate-100 font-sans">
      {/* Hijri Wisdom & Gold Day Tracker */}
      <div className="w-full py-2 px-6 border-b border-white/5 bg-slate-900 flex items-center justify-between text-[11px] font-black uppercase tracking-wider">
        <div className="flex items-center gap-6">
          <span className="text-slate-400">LUNAR CYCLE: {lunarWisdom.hijriDay} {lunarWisdom.month}</span>
          <div className="flex gap-2">
            {lunarWisdom.goldDays.map(day => (
              <span 
                key={day} 
                className={`px-3 py-0.5 rounded border transition-all ${day === 17 ? 'border-amber-500 bg-amber-500/10 text-amber-500 animate-pulse shadow-[0_0_15px_rgba(245,158,11,0.4)]' : 'border-slate-700 text-slate-600'}`}
              >
                GOLD DAY {day}
              </span>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-4 text-red-500">
          <i className="fa-solid fa-satellite text-[10px] animate-pulse"></i>
          <span className="font-bold tracking-widest">SURGICAL TELEMETRY ACTIVE</span>
        </div>
      </div>

      <Header activeTab={activeTab} setActiveTab={setActiveTab} gender={gender} setGender={setGender} />

      <div className="flex flex-1 overflow-hidden">
        {/* Navigation Sidebar */}
        <aside className="w-72 border-r border-white/5 bg-slate-950 p-6 flex flex-col gap-8">
          <div>
            <h3 className="text-[10px] font-black uppercase text-slate-500 mb-4 tracking-widest">Clinical Protocol</h3>
            <div className="space-y-2">
              {[
                { id: 'hijama', label: 'Hijama (Cupping)', icon: 'fa-circle-dot' },
                { id: 'leech', label: 'Leech (Sülük)', icon: 'fa-bug' },
                { id: 'nutrition', label: 'Nutrition Guide', icon: 'fa-leaf' }
              ].map(t => (
                <button
                  key={t.id}
                  onClick={() => setActiveTherapy(t.id as any)}
                  className={`w-full flex items-center gap-3 px-5 py-3.5 rounded-2xl text-[11px] font-black uppercase transition-all ${
                    activeTherapy === t.id 
                    ? 'bg-red-600 text-white shadow-xl shadow-red-900/20' 
                    : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                  }`}
                >
                  <i className={`fa-solid ${t.icon} w-5`}></i>
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-auto space-y-4">
            {activeTherapy === 'leech' && (
              <div className="p-4 rounded-xl bg-emerald-900/20 border border-emerald-500/20 text-emerald-400 text-[10px] leading-relaxed animate-in fade-in slide-in-from-left-2">
                <p className="font-black mb-1 uppercase tracking-widest text-[9px] text-emerald-500">Leech Therapy Protocol</p>
                Targeting areas of venous congestion. Natural Hirudin release protocol active. Hirudo medicinalis application for localized congestion.
              </div>
            )}
            {activeTherapy === 'nutrition' && (
              <div className="p-4 rounded-xl bg-amber-900/20 border border-amber-500/20 text-amber-400 text-[10px] leading-relaxed animate-in fade-in slide-in-from-left-2">
                <p className="font-black mb-1 uppercase tracking-widest text-[9px] text-amber-500">Post-Therapy Nutrition</p>
                Post-therapy: Avoid red meat for 24h. Hydrate with honey water. No heavy proteins for 24h.
              </div>
            )}
            <div className="p-4 rounded-xl bg-slate-900 border border-white/5">
              <div className="flex justify-between text-[10px] font-black text-slate-500 uppercase mb-2">
                <span>Torso Alignment</span>
                <span className="text-red-500">LOCKED (X=50)</span>
              </div>
              <div className="h-1 w-full bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-red-600 w-full" />
              </div>
            </div>
          </div>
        </aside>

        {/* Main Interface */}
        <main className="flex-1 overflow-hidden p-8 flex flex-col gap-6 bg-slate-950/50">
          {activeTab === 'mapping' ? (
            <div className="h-full flex flex-col gap-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-black uppercase tracking-tight">Surgical Workspace</h2>
                  <p className="text-xs text-slate-500 mt-1 font-mono uppercase tracking-widest">Enforcing X:40-60 Centralized Boundary</p>
                </div>
                <div className="flex gap-4">
                  <button onClick={reset} className="px-6 py-2 rounded-xl bg-slate-900 border border-white/10 text-[10px] font-black uppercase hover:bg-slate-800">
                    Purge Session
                  </button>
                  <button 
                    onClick={startAnalysis} 
                    disabled={!image || isLoading} 
                    className="px-8 py-2 rounded-xl bg-red-600 text-white text-[10px] font-black uppercase hover:bg-red-500 disabled:opacity-50 flex items-center gap-2 shadow-2xl shadow-red-900/40"
                  >
                    {isLoading ? <i className="fa-solid fa-spinner animate-spin"></i> : <i className="fa-solid fa-crosshairs"></i>}
                    Execute Precise Map
                  </button>
                </div>
              </div>

              <div className="flex-1 glass-panel rounded-[2rem] relative flex items-center justify-center overflow-hidden border-white/5 shadow-2xl">
                {!image ? (
                  <label className="flex flex-col items-center gap-4 cursor-pointer group">
                    <div className="w-24 h-24 rounded-3xl bg-white/5 border border-dashed border-white/20 flex items-center justify-center group-hover:border-red-500/40 group-hover:bg-red-500/5 transition-all">
                      <i className="fa-solid fa-folder-open text-slate-600 text-3xl group-hover:text-red-500"></i>
                    </div>
                    <span className="text-[11px] font-black uppercase text-slate-500 tracking-widest group-hover:text-slate-300">Input Anatomical Scan</span>
                    <input type="file" className="hidden" onChange={handleFileUpload} />
                  </label>
                ) : (
                  <div className="relative h-full w-full flex items-center justify-center p-8 bg-slate-900/20">
                    <img src={image} className="max-h-full max-w-full rounded-2xl shadow-2xl border border-white/10 object-contain brightness-95 contrast-105" />
                    {mapping && <AnatomyOverlay points={mapping.points} mode={activeTherapy} />}
                  </div>
                )}
              </div>
            </div>
          ) : activeTab === 'marathon' ? (
            <MarathonAgent sessions={sessions} />
          ) : (
            <VibeEngineer logs={logs} />
          )}
        </main>

        {/* Telemetry Sidebar */}
        <aside className="w-80 border-l border-white/5 bg-slate-950 p-6 flex flex-col gap-6">
          <div className="p-5 rounded-2xl bg-white/[0.03] border border-white/5 space-y-4">
            <h3 className="text-[10px] font-black uppercase text-slate-500 tracking-widest border-b border-white/5 pb-2">Anatomical Telemetry</h3>
            <div className="space-y-4">
              <DiagnosticRow label="Spine Offset" value="0.000mm" color="text-red-500" />
              <DiagnosticRow label="Torso Coverage" value="VERIFIED (X40-60)" color="text-emerald-500" />
              <DiagnosticRow label="Mapping System" value="V6.0-SURGICAL" color="text-white" />
            </div>
          </div>

          <div className="flex-1 flex flex-col gap-4">
            <h3 className="text-[10px] font-black uppercase text-slate-500 tracking-widest px-2">Anatomical Point List</h3>
            <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-2">
              {mapping ? mapping.points.map((p) => (
                <div key={p.id} className="p-3 bg-white/5 rounded-xl border border-white/5 flex items-start justify-between hover:bg-white/10 transition-all group">
                  <div>
                    <p className="text-[10px] font-black text-red-600">{p.id.toUpperCase()}</p>
                    <p className="text-[11px] font-bold text-slate-200">{p.name}</p>
                  </div>
                  <span className="text-[9px] font-mono text-slate-600 font-bold group-hover:text-red-500 transition-colors">X:{p.x.toFixed(1)}</span>
                </div>
              )) : (
                <div className="h-full flex items-center justify-center text-[10px] text-slate-600 font-black uppercase tracking-widest italic opacity-20 py-20 text-center px-4">
                  Awaiting Frame Input...
                </div>
              )}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};

const DiagnosticRow = ({ label, value, color }: { label: string, value: string, color: string }) => (
  <div className="flex justify-between items-end">
    <span className="text-[9px] font-black text-slate-500 uppercase">{label}</span>
    <span className={`text-[10px] font-mono font-black ${color}`}>{value}</span>
  </div>
);

export default App;
