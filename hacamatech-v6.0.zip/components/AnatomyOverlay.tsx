
import React from 'react';
import { HijamaPoint } from '../types';

interface AnatomyOverlayProps {
  points: HijamaPoint[];
  mode?: 'hijama' | 'leech' | 'nutrition';
}

const AnatomyOverlay: React.FC<AnatomyOverlayProps> = ({ points, mode = 'hijama' }) => {
  const p1 = points.find(p => p.id === 'p1');
  const spineX = p1 ? p1.x : 50;
  
  // Clinical surgical red for high visibility on skin
  const pointColor = "#dc2626"; 

  return (
    <svg className="absolute top-0 left-0 w-full h-full pointer-events-none" viewBox="0 0 100 100" preserveAspectRatio="none">
      <defs>
        <filter id="preciseRedGlow">
          <feGaussianBlur stdDeviation="0.3" result="blur"/>
          <feComposite in="SourceGraphic" in2="blur" operator="over"/>
        </filter>
      </defs>

      {/* Clinical Spine Baseline Verification */}
      <line 
        x1={spineX} y1="0" x2={spineX} y2="100" 
        stroke="rgba(220, 38, 38, 0.3)" 
        strokeWidth="0.12" 
        strokeDasharray="0.5, 0.5" 
      />
      
      {points.map((p) => {
        const isLeft = p.x < spineX;
        const isSpinePoint = ['p1', 'p8', 'p9', 'p10'].includes(p.id);
        
        return (
          <g key={p.id} className="animate-in fade-in zoom-in-50 duration-300">
            {/* Horizontal Alignment Trace */}
            {!isSpinePoint && (
              <line 
                x1={p.x} y1={p.y} x2={spineX} y2={p.y}
                stroke="rgba(255,255,255,0.1)"
                strokeWidth="0.05"
                strokeDasharray="0.1, 0.1"
              />
            )}

            {/* Surgical Point: Solid Clinical Red */}
            <circle 
              cx={p.x} cy={p.y} r="0.9" 
              fill={pointColor}
              filter="url(#preciseRedGlow)"
            />
            
            {/* White Ring for Depth Contrast */}
            <circle 
              cx={p.x} cy={p.y} r="1.3" 
              fill="none" 
              stroke="white"
              strokeWidth="0.1" 
              className="opacity-40"
            />

            {/* Label Tag */}
            <g transform={`translate(${isSpinePoint ? p.x + 3 : (isLeft ? p.x - 3 : p.x + 3)}, ${p.y})`}>
              <text 
                textAnchor={!isSpinePoint && isLeft ? "end" : "start"}
                className="fill-white font-mono font-black" 
                style={{ fontSize: '1.6px', letterSpacing: '0.05em' }}
              >
                {p.id.toUpperCase()}
              </text>
              <text 
                y="1.5"
                textAnchor={!isSpinePoint && isLeft ? "end" : "start"}
                fill={pointColor}
                className="font-black uppercase tracking-widest" 
                style={{ fontSize: '1.0px' }}
              >
                {p.name.split(' (')[0]}
              </text>
            </g>
          </g>
        );
      })}
    </svg>
  );
};

export default AnatomyOverlay;
