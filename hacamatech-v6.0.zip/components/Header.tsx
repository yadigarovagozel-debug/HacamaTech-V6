
import React from 'react';

interface HeaderProps {
  activeTab: 'mapping' | 'marathon' | 'vibe';
  setActiveTab: (tab: 'mapping' | 'marathon' | 'vibe') => void;
  gender: 'male' | 'female';
  setGender: (gender: 'male' | 'female') => void;
}

const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, gender, setGender }) => {
  return (
    <header className="z-50 border-b border-white/5 bg-slate-950 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="bg-emerald-500 w-12 h-12 rounded-2xl flex items-center justify-center shadow-2xl shadow-emerald-500/20 rotate-3">
            <i className="fa-solid fa-stethoscope text-white text-2xl"></i>
          </div>
          <div>
            <h1 className="font-black text-xl leading-none tracking-tight">HACAMATECH <span className="text-emerald-400">V6.0</span></h1>
            <p className="text-[10px] text-slate-500 uppercase tracking-widest font-black mt-1">Holistic Clinical Intelligence</p>
          </div>
        </div>

        <nav className="flex items-center gap-1 bg-slate-900 p-1.5 rounded-2xl border border-white/5">
          {[
            { id: 'mapping', label: 'Suite', icon: 'fa-layer-group' },
            { id: 'marathon', label: 'History', icon: 'fa-folder-tree' },
            { id: 'vibe', label: 'System', icon: 'fa-microchip' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-6 py-2 rounded-xl text-xs font-black uppercase transition-all ${
                activeTab === tab.id 
                ? 'bg-emerald-600 text-white shadow-lg' 
                : 'text-slate-500 hover:text-white hover:bg-white/5'
              }`}
            >
              <i className={`fa-solid ${tab.icon} text-[10px]`}></i>
              {tab.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-6">
          {/* Gender Toggle */}
          <div className="flex bg-slate-900 rounded-xl p-1 border border-white/5">
            <button 
              onClick={() => setGender('male')}
              className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${gender === 'male' ? 'bg-blue-600 text-white' : 'text-slate-500'}`}
            >
              Male
            </button>
            <button 
              onClick={() => setGender('female')}
              className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${gender === 'female' ? 'bg-rose-600 text-white' : 'text-slate-500'}`}
            >
              Female
            </button>
          </div>

          <div className="h-10 w-[1px] bg-white/5" />

          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-[10px] text-slate-500 font-black uppercase">Clinician</p>
              <p className="text-xs font-bold">Dr. Ibrahim</p>
            </div>
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center overflow-hidden">
               <i className="fa-solid fa-user-md text-emerald-400"></i>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
