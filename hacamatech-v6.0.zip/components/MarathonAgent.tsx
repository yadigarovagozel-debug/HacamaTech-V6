
import React from 'react';
import { PatientSession } from '../types';

interface MarathonAgentProps {
  sessions: PatientSession[];
}

const MarathonAgent: React.FC<MarathonAgentProps> = ({ sessions }) => {
  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Marathon Recovery Tracking</h2>
          <p className="text-slate-400 text-sm">Long-term patient progress and session archives.</p>
        </div>
        <button className="bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-emerald-600/30 transition-all">
          Generate Report
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-panel p-6 rounded-2xl">
          <p className="text-xs text-slate-500 uppercase font-bold mb-1">Total Sessions</p>
          <p className="text-3xl font-bold">{sessions.length}</p>
        </div>
        <div className="glass-panel p-6 rounded-2xl">
          <p className="text-xs text-slate-500 uppercase font-bold mb-1">Avg Confidence</p>
          <p className="text-3xl font-bold text-emerald-400">96.4%</p>
        </div>
        <div className="glass-panel p-6 rounded-2xl">
          <p className="text-xs text-slate-500 uppercase font-bold mb-1">Next Session</p>
          <p className="text-3xl font-bold text-blue-400">14 Days</p>
        </div>
      </div>

      <div className="glass-panel rounded-2xl overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-900/50 border-b border-white/5">
            <tr>
              <th className="px-6 py-4 font-bold uppercase tracking-wider text-[10px] text-slate-500">Session Date</th>
              <th className="px-6 py-4 font-bold uppercase tracking-wider text-[10px] text-slate-500">Preview</th>
              <th className="px-6 py-4 font-bold uppercase tracking-wider text-[10px] text-slate-500">Status</th>
              <th className="px-6 py-4 font-bold uppercase tracking-wider text-[10px] text-slate-500">Notes</th>
              <th className="px-6 py-4 font-bold uppercase tracking-wider text-[10px] text-slate-500">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {sessions.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-slate-500 italic">No session history available yet. Perform an analysis to begin tracking.</td>
              </tr>
            ) : (
              sessions.map((session) => (
                <tr key={session.id} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4 font-semibold">{session.date}</td>
                  <td className="px-6 py-4">
                    <img src={session.imageUrl} className="w-12 h-12 object-cover rounded-lg border border-white/10" alt="History" />
                  </td>
                  <td className="px-6 py-4">
                    <span className="bg-emerald-500/20 text-emerald-400 text-[10px] px-2 py-1 rounded-full border border-emerald-500/30 uppercase font-bold">
                      {session.recoveryStatus}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-slate-400 text-xs">{session.notes}</td>
                  <td className="px-6 py-4">
                    <button className="text-blue-400 hover:text-blue-300 font-medium">Review Map</button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MarathonAgent;
