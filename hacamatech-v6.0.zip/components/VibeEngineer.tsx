
import React from 'react';
import { VerificationLog } from '../types';

interface VibeEngineerProps {
  logs: VerificationLog[];
}

const VibeEngineer: React.FC<VibeEngineerProps> = ({ logs }) => {
  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Vibe Engineering Dashboard</h2>
          <p className="text-slate-400 text-sm">Self-verifying code protocols and real-time anatomical audit.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse"></span>
          <span className="text-xs font-mono text-emerald-500">LIVE AUDIT ACTIVE</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="glass-panel p-6 rounded-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-5">
            <i className="fa-solid fa-microchip text-8xl"></i>
          </div>
          <h3 className="text-sm font-bold uppercase tracking-widest text-emerald-400 mb-4">Core Verification Logic</h3>
          <div className="space-y-4 font-mono text-xs text-slate-300">
            <div className="p-3 bg-black/40 rounded-lg border border-emerald-500/20">
              <p className="text-emerald-500 font-bold mb-1">// SYMMETRY_VALIDATOR_V2</p>
              <p>const deltaX = Math.abs(pLeft.x - pRight.x);</p>
              <p>return deltaX &lt; 0.05 * imageWidth ? 'VALID' : 'FAILED';</p>
            </div>
            <div className="p-3 bg-black/40 rounded-lg border border-blue-500/20">
              <p className="text-blue-500 font-bold mb-1">// SKIN_TISSUE_PROBABILITY</p>
              <p>const hsv = pixel.toHSV();</p>
              <p>return isSkinColor(hsv) &amp;&amp; !isBackground(hsv);</p>
            </div>
          </div>
        </div>

        <div className="glass-panel p-6 rounded-2xl">
          <h3 className="text-sm font-bold uppercase tracking-widest text-blue-400 mb-4">System Health</h3>
          <div className="space-y-4">
            {[
              { label: 'Gemini 3 Pro Integration', status: 'Optimal', color: 'text-emerald-400' },
              { label: 'Spatial Reasoner Engine', status: 'Stable', color: 'text-emerald-400' },
              { label: 'Anatomy Mapping Bias', status: '0.002%', color: 'text-blue-400' },
              { label: 'API Latency', status: '840ms', color: 'text-blue-400' }
            ].map((item, idx) => (
              <div key={idx} className="flex justify-between items-center py-2 border-b border-white/5 last:border-0">
                <span className="text-sm text-slate-400">{item.label}</span>
                <span className={`text-sm font-mono font-bold ${item.color}`}>{item.status}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="glass-panel p-6 rounded-2xl">
        <h3 className="text-sm font-bold uppercase tracking-widest text-slate-500 mb-4">Execution Audit Logs</h3>
        <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
          {logs.map((log, idx) => (
            <div key={idx} className="flex flex-col md:flex-row gap-2 md:gap-4 p-3 bg-slate-900/30 rounded-xl border border-white/5">
              <span className="text-slate-500 font-mono text-[10px] whitespace-nowrap">{log.timestamp}</span>
              <span className={`text-[10px] font-black tracking-widest w-24 ${log.status === 'PASSED' ? 'text-emerald-400' : 'text-rose-400'}`}>[{log.status}]</span>
              <span className="text-xs font-bold text-blue-400 w-32">{log.component}</span>
              <span className="text-xs text-slate-300">{log.details}</span>
            </div>
          ))}
          {logs.length === 0 && <p className="text-center text-slate-600 py-10 font-mono italic text-sm">No verification logs available. Start an analysis to generate audit data.</p>}
        </div>
      </div>
    </div>
  );
};

export default VibeEngineer;
