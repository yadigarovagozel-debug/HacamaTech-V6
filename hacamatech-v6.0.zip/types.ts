
export interface HijamaPoint {
  id: string;
  name: string;
  x: number; // 0-100 normalized
  y: number; // 0-100 normalized
  description: string;
  verified: boolean;
}

export interface PatientSession {
  id: string;
  date: string;
  imageUrl: string;
  points: HijamaPoint[];
  recoveryStatus: 'Excellent' | 'Improving' | 'Stable' | 'Pending';
  notes: string;
}

export interface MappingResult {
  points: HijamaPoint[];
  anatomicalConfidence: number;
  landmarks: {
    spineDetected: boolean;
    scapulaDetected: boolean;
    c7Detected: boolean;
  };
}

export interface VerificationLog {
  timestamp: string;
  component: string;
  status: 'PASSED' | 'FAILED';
  details: string;
}
